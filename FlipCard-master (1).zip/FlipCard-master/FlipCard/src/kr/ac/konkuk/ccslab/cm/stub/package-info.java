/**
 * The stub package contains stub classes with which an application can interact with CM. 
 * The application can access CM APIs and other internal CM objects through the stub object.
 * @author CCSLab, Konkuk University
 *
 */
package kr.ac.konkuk.ccslab.cm.stub;